import * as S from "./styles";
const BASE_URL = "https://image.tmdb.org/t/p/w500";

const PopularPage = ({ movie }) => {
    return (
        //이렇게 재활용 하되, 불러오는 url, header만 달라지면 되는거 아닌가?

        <S.MovieCard>
            <S.Image src={`${BASE_URL}${movie.poster_path}`} alt={movie.title} />
            <S.Overlay />
        </S.MovieCard>
    );
};

export default PopularPage;
