const CategoryPage=()=>{
return(
    <h1 color={'white'}>
         ca
    </h1>
)
}

export default CategoryPage