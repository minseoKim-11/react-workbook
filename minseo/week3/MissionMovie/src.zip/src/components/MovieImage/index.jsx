import { useEffect, useState } from "react";
import axios from "axios";
import MovieCard from "../MovieCard";
import { MovieContainer } from "./styles";

const MovieImage = () => {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const getMovies = async () => {
      try {
        const res = await axios.get(
            'https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc',
            {
              headers: {
                Authorization: `Bearer ${process.env.REACT_APP_TMDB_TOKEN}`,
                accept: "application/json"
              }
            }
        );
        setMovies(res.data.results);
      } catch (error) {
        console.error("API 요청 실패", error);
      }
    };

    getMovies();
  }, []);

  return (
      <MovieContainer>
        {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
        ))}
      </MovieContainer>
  );
};

export default MovieImage;