import styled from "styled-components";

export const MovieContainer = styled.div`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 16px;
    padding: 30px;
    justify-content: center;
`;
