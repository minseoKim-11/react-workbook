import styled from 'styled-components';

export const LayoutContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 100vh;
`;

export const BodyContainer = styled.div`
  display: flex;
  flex: 1;
  height: 100%;
`;

export const MainContent = styled.main`
  flex: 1;
  padding: 1rem;
    background-color: #000;
  overflow-y: auto;
`;
