import * as S from "./styles";

const BASE_URL = "https://image.tmdb.org/t/p/w500";

const MovieCard = ({ movie }) => {
    return (
        <S.MovieCard>
            <S.Image src={`${BASE_URL}${movie.poster_path}`} alt={movie.title} />
            <S.Overlay />
        </S.MovieCard>
    );
};

export default MovieCard;
