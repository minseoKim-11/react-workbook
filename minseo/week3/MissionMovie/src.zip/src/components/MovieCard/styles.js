import styled from "styled-components";

export const MovieCard = styled.div`
  position: relative;
`;

export const Image = styled.img`
  width: 120px;
  height: auto;
  border-radius: 8px;
`;

export const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 0;
  transition: opacity 0.3s ease;
  border-radius: 8px;

  &:hover {
    opacity: 1;
  }
`;
