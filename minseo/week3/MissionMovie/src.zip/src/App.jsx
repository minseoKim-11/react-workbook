import './App.css';
import {createBrowserRouter, RouterProvider} from "react-router-dom";
import Layout from './components/Layout/index.jsx';
import MovieCard from "./components/MovieCard/index.jsx";
import SignupPage from "./pages/signup.jsx";
import LoginPage from "./pages/login.jsx";
import SearchPage from "./pages/search.jsx";
import CategoryPage from "./pages/category.jsx";
import {useEffect, useState} from "react";
import Popular from "./pages/movies/popular.jsx";


const router = createBrowserRouter([
    {
        path:'/',
        element:<Layout/>,
        children:[
            {
                index:true,
                element:<popular/>
            },
            {
                path:'login',
                element:<LoginPage/>
            },
            {
                path:'signup',
                element:<SignupPage/>
            },
            {
                path:'search',
                element:<SearchPage/>
            },
            {
                path:'category',
                element:<CategoryPage/>
            },
            {
                path:'popular',
                element:<PopularPage/>
            },
            {
                path:'now-playng',
                element:<NowPlayingPage/>
            },
            {
                path:'top-rated',
                element:<TopRatedPage/>
            },
            {
                path:'up-coming',
                element:<UpComingPage/>
            }
        ]
    }]
)


function App() {
    return(
        <RouterProvider router={router}/>
        )
}

export default App;
